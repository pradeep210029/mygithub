/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>

using namespace std;
class node{
    public:
    int data;
    node* left;
    node* right;
     
    node(int d)
    {
        data=d;
        left=NULL;
        right=NULL;
    }
};

node* inst(node* root)
{
    int data;
    cout<<"Enter root data: "<<" ";
    cin>>data;
    root=new node(data);
    
    if(data==-1)
    {
        return NULL;
    }
    
    cout<<"Enter the left of the: "<<data<<endl;
    root->left=inst(root->left);
    cout<<"Enter the right of the: "<<data<<endl;
    root->right=inst(root->right);
    return root;
}
int countlif(node* root ,int &count)
{
    if(root==NULL)
    {
        return 0;
    }
    if(root->left==NULL && root->right==NULL)
    {
        count++;
    }
    countlif(root->left,count);
    countlif(root->right,count);
    return count;
}
int main()
{
    node *root=NULL;
    node *temp=inst(root);
    int count=0;
    countlif(temp,count);
    cout<<"NO of leef Nodes: "<<count;
   
    return 0;
}
