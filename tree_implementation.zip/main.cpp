/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <bits/stdc++.h>

using namespace std;
class node{
    public:
    int data;
    node* left;
    node* right;
     
    node(int d)
    {
        data=d;
        left=NULL;
        right=NULL;
    }
};

node* inst(node* root)
{
    int data;
    cout<<"Enter root data: "<<" ";
    cin>>data;
    root=new node(data);
    
    if(data==-1)
    {
        return NULL;
    }
    
    cout<<"Enter the left of the: "<<data<<endl;
    root->left=inst(root->left);
    cout<<"Enter the right of the: "<<data<<endl;
    root->right=inst(root->right);
    return root;
}
int count(node* root)
{
    if(root==NULL)
    {
        return 0;
    }
    
    int l=count(root->left);
    int r=count(root->right);
    return 1+max(l,r);
    
}
void prnt(node* root){
    if(root==NULL)
    {
        return ;
    }
    prnt(root->left);
    cout<<root->data<<" ";
    prnt(root->right);
    
}
void rp(node* root,int ct)
{

if(root==NULL)
{  return ;}
    if(ct==1){
    cout<<root->data<<" ";}
    rp(root->left,ct-1);
    rp(root->right,ct-1);
    
}
int main()
{
    node* root=NULL;
    node*  ch=root;
    node *temp=inst(root);
    cout<<"Element of the tree: "<<endl;
    prnt(temp);
    cout<<endl;
    int lvl=count(temp);
    cout<<"level of the tree: "<<lvl<<endl;
    cout<<"Level wise data in Reverse order: "<<endl;
    for(int i=lvl;i>=1;i--)
    {
        rp(temp,i);
        cout<<endl;
    }
    return 0;
}
